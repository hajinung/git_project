^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package open_manipulator_perceptions
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2018-06-01)
------------------
* added new open_manipulator_perceptions package
* added perception packages as AR marker, Object recognition and so on
* Contributors: Darby Lim
